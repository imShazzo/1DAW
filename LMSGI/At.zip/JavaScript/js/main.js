const productos  = [{nombre: "Raton", precio: 25, enStock:true},{nombre: "Teclado", precio:60, enStock: true}];
const boton = document.querySelector("#btnOfertas");
const lista = document.querySelector("#listaProductos");


boton.addEventListener("click",() =>{
    lista.innerHTML = "";
    const filtrados = productos.filter(prod => prod.precio < 50 && prod.enStock===true);
    filtrados.forEach(prod => { const li = document.createElement("li");
        li.textContent = `${prod.nombre} - ${prod.precio}€`;
        lista.appendChild(li);
        
    });
        
    });