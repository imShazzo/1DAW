SET SERVEROUTPUT ON;

DECLARE 
BEGIN
datosclientes(1);

END;
/