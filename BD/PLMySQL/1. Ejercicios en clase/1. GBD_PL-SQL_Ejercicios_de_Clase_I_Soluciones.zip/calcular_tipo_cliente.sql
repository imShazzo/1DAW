CREATE OR REPLACE FUNCTION calcular_tipo_cliente(cod_cli clientes.codigoCliente%TYPE)
RETURN NUMBER
IS
      v_tipo NUMBER;
      v_lim_credito clientes.limiteCredito%TYPE;
BEGIN
     -- Se consulta el l�mite de cr�dito del cliente
     SELECT limiteCredito INTO v_lim_credito
     FROM clientes
     WHERE codigoCliente = cod_cli;

	 -- Se calcula el tipo seg�n la cantidad del l�mite de cr�dito	
	 IF (v_lim_credito < 10000) THEN  -- menor que 10.000
		  v_tipo:=1;
	    ELSIF (v_lim_credito < 100000) THEN -- igual o mayor que 10.000 (por el ELSE) y menor que 100.000
		  v_tipo:=2;
	      ELSE -- igual o mayor que 100.000 (por el ELSE)
		  v_tipo:=3;
         END IF;
	 
	 -- Se devuelve el tipo de cliente
	 RETURN v_tipo;

  EXCEPTION -- Se trata la Excepci�n
     WHEN NO_DATA_FOUND THEN
       RETURN -1;
END;



