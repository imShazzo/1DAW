CREATE OR REPLACE PROCEDURE mostrar_info_cliente(cod_cli clientes.codigoCliente%TYPE)
IS
      v_nom_cli clientes.nombreCliente%TYPE;
	  v_tlf_cli clientes.telefono%TYPE;
	  v_cod_emp clientes.codigoEmpleadoRepVentas%TYPE;
	  v_nom_emp empleados.nombre%TYPE;
	  v_cod_ofi empleados.codigoOficina%TYPE;
	  v_ciudad_pais_ofi  VARCHAR2(80);
	  v_tipo_cli NUMBER;
BEGIN
     -- Se consulta los datos del cliente
     SELECT cli.nombreCliente, cli.telefono, cli.codigoEmpleadoRepVentas, emp.nombre, emp.codigoOficina INTO v_nom_cli, v_tlf_cli, v_cod_emp, v_nom_emp, v_cod_ofi
     FROM clientes cli, empleados emp
     WHERE cli.codigoEmpleadoRepVentas= emp.codigoEmpleado 
	   AND codigoCliente = cod_cli;

	 -- Se calcula la ciudad y el pais de la oficina
	v_ciudad_pais_ofi := calcular_ciudad_pais(v_cod_ofi);
	
	-- Se calcula el tipo de cliente
	v_tipo_cli := calcular_tipo_cliente(cod_cli);
	
	-- Se Muestran los datos por pantalla
	DBMS_OUTPUT.PUT_LINE('--------- DATOS CLIENTE ----------');
	DBMS_OUTPUT.PUT_LINE('CODIGO CLIENTE: ' || cod_cli);
	DBMS_OUTPUT.PUT_LINE('NOMBRE CLIENTE: ' || v_nom_cli);
	DBMS_OUTPUT.PUT_LINE('TELEFONO CLIENTE: ' || v_tlf_cli);
	DBMS_OUTPUT.PUT_LINE('TIPO CLIENTE: ' || v_tipo_cli);
	
	DBMS_OUTPUT.PUT_LINE('--------- DATOS EMPLEADO REPRESENTANTE DE VENTAS ----------');
	DBMS_OUTPUT.PUT_LINE('CODIGO EMPLEADO REP VENTAS: ' || v_cod_emp);
	DBMS_OUTPUT.PUT_LINE('NOMBRE EMPLEADO : ' || v_nom_emp);
	
	DBMS_OUTPUT.PUT_LINE('--------- DATOS OFICINA ----------');
	DBMS_OUTPUT.PUT_LINE('CODIGO OFICINA: ' || v_cod_ofi);
	DBMS_OUTPUT.PUT_LINE('CIUDAD(PAIS) OFICINA: ' || v_ciudad_pais_ofi);
	
	
  EXCEPTION -- Se trata la Excepci�n
     WHEN NO_DATA_FOUND THEN
       	DBMS_OUTPUT.PUT_LINE('Error:  No existe ning�n cliente con ese c�digo');
	 WHEN OTHERS THEN
	 	DBMS_OUTPUT.PUT_LINE('Se ha producido un error en la aplicaci�n');
END;



