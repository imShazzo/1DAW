CREATE OR REPLACE FUNCTION calcular_ciudad_pais(cod_ofi oficinas.codigoOficina%TYPE)
RETURN VARCHAR2
IS
      v_ciudad_pais VARCHAR2(80);
BEGIN
     -- Se consulta la ciudad(pais)
     SELECT ciudad || '('||pais||')' INTO v_ciudad_pais
     FROM oficinas
     WHERE codigoOficina = cod_ofi;

     RETURN v_ciudad_pais;

  EXCEPTION
     WHEN NO_DATA_FOUND THEN
       RETURN 'No existe oficina';
END;
