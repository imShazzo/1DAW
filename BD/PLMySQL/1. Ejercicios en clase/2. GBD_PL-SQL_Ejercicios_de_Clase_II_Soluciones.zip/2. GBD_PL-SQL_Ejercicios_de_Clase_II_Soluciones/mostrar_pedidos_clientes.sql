CREATE OR REPLACE PROCEDURE mostrar_pedidos_cli
AS
	  -- Definici�n del cursor exterior que recorre todos los clientes
      CURSOR c_clientes IS SELECT codigoCliente, nombreCliente, telefono
                           FROM clientes;

      v_cod_cli clientes.codigoCliente%TYPE;
      v_nom_cli clientes.nombrecliente%TYPE;
      v_tlf_cli clientes.telefono%TYPE;

	  -- Definici�n del cursor interior que recorre los pedidos de cada cliente
      CURSOR c_pedidos IS SELECT codigoPedido, fechaPedido, estado, fechaEntrega
                          FROM pedidos
                          WHERE codigoCliente = v_cod_cli; -- esto toma el c�digo de cada cliente


BEGIN
       OPEN c_clientes;
		-- Bucle externo que recorre el cursor de clientes
       LOOP
            FETCH c_clientes INTO v_cod_cli, v_nom_cli, v_tlf_cli;
            EXIT WHEN c_clientes%NOTFOUND;

			-- Se muestran los datos del cliente
            DBMS_OUTPUT.PUT_LINE('---- CLIENTE ');
            DBMS_OUTPUT.PUT_LINE('CODIGO: ' || v_cod_cli);
            DBMS_OUTPUT.PUT_LINE('NOMBRE: ' || v_nom_cli);
            DBMS_OUTPUT.PUT_LINE('TELEFONO: ' || v_tlf_cli);

			-- Bucle interno que muestra los datos de los pedidos de ese cliente
            DBMS_OUTPUT.PUT_LINE('----------------- PEDIDOS ');	
			FOR v_reg_pedidos IN c_pedidos LOOP
					 DBMS_OUTPUT.PUT_LINE('                  C�digo: ' || v_reg_pedidos.codigoPedido);
					 DBMS_OUTPUT.PUT_LINE('                  Fecha: ' || TO_CHAR(v_reg_pedidos.fechaPedido,'DD/MONTH/YYYY'));
					 DBMS_OUTPUT.PUT_LINE('                  Estado: ' || v_reg_pedidos.estado);
					 IF (v_reg_pedidos.estado='Entregado') THEN
						 DBMS_OUTPUT.PUT_LINE('                  Entrega: ' || TO_CHAR(v_reg_pedidos.fechaEntrega,'DD/MONTH/YYYY'));
					END IF;
					DBMS_OUTPUT.PUT_LINE('                  ---------------');
            END LOOP;
       END LOOP;

	   CLOSE c_clientes;
END;