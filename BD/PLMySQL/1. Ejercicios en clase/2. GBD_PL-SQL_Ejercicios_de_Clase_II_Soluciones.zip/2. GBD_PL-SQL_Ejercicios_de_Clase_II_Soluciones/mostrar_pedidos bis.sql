CREATE OR REPLACE PROCEDURE mostrar_pedidos(cod_cli clientes.codigoCliente%TYPE, estado_pedido pedidos.estado%TYPE)
IS

	-- Se define el cursor para recorrer los pedidos
	CURSOR c_pedidos IS SELECT codigoPedido, fechaPedido
						FROM pedidos
						WHERE codigoCliente = cod_cli 
							AND UPPER(estado)=UPPER(estado_pedido)
						ORDER BY fechaPedido;

	v_nom_cli clientes.nombreCliente%TYPE;
	v_tlf_cli clientes.telefono%TYPE;
	v_importe_pedido NUMBER;

-- --------------  Funci�n local para calcular el importe total de los pedidos
FUNCTION calcular_importe_pedido(cod_ped pedidos.codigoPedido%TYPE)
RETURN NUMBER
IS
    v_importe NUMBER:=0;
BEGIN
    -- El importe total de un pedido ser� la suma de (cantidad x precio) para los productos del pedido
	SELECT NVL(SUM(cantidad*precioUnidad),0) INTO v_importe
	FROM detallePedidos
	WHERE codigoPedido = cod_ped;

	RETURN v_importe;
	
	EXCEPTION
		WHEN NO_DATA_FOUND THEN
		    RETURN 0;
END;
	

-- ------------ PRINCIPAL
							
BEGIN

	-- Se consulta si existe el cliente
	SELECT nombreCliente, telefono INTO v_nom_cli, v_tlf_cli
	FROM clientes
	WHERE codigoCliente = cod_cli;

	-- Se muestra los datos del cliente
	DBMS_OUTPUT.PUT_LINE('-------- DATOS CLIENTE ---------');
	DBMS_OUTPUT.PUT_LINE('NOMBRE CLIENTE: '||v_nom_cli);
	DBMS_OUTPUT.PUT_LINE('TLF CLIENTE: '||v_tlf_cli);

	-- Se muestran el listado de pedidos de ese cliente
	DBMS_OUTPUT.PUT_LINE('-------- LISTADO DE PEDIDOS ---------');
	DBMS_OUTPUT.PUT_LINE('CODIGO ---------- FECHA --------------- IMPORTE');
    FOR v_pedido IN c_pedidos LOOP -- Se recorre el cursor
	
			-- Se calcula el importe del pedido (se llama a una funci�n local)
			v_importe_pedido := calcular_importe_pedido(v_pedido.codigoPedido);
	
			-- Se muestran los datos
			DBMS_OUTPUT.PUT_LINE(v_pedido.codigoPedido || ' --------- ' || TO_CHAR(v_pedido.fechaPedido,'dd/month/yyyy') || ' --------- ' || v_importe_pedido);
	END LOOP;
	
	EXCEPTION
		WHEN NO_DATA_FOUND THEN
				DBMS_OUTPUT.PUT_LINE('Error no existe el cliente especificado');
		WHEN TOO_MANY_ROWS THEN
				DBMS_OUTPUT.PUT_LINE('Error existen varios clientes con el mismo c�digo');
		WHEN OTHERS THEN
				DBMS_OUTPUT.PUT_LINE('Error en la aplicaci�n');
END;