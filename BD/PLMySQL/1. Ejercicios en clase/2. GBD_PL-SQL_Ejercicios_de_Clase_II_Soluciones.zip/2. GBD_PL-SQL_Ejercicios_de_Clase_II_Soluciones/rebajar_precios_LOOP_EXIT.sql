CREATE OR REPLACE PROCEDURE rebajar_precios(gama_prod productos.gama%TYPE, importe NUMBER, porcentaje NUMBER)
IS

	-- Se define el cursor para recorrer los productos
	CURSOR c_productos	IS SELECT codigoProducto, precioVenta
						FROM productos
						WHERE gama = gama_prod
						FOR UPDATE OF precioVenta; 

	v_cod_prod productos.codigoProducto%TYPE; -- c�digo del producto
	v_precio_venta productos.precioVenta%TYPE; -- precio de venta del producto
	v_gama gamasProductos.gama%TYPE;  -- gama

	v_conta_importe NUMBER :=0; -- contador de productos rebajados por importe
	v_conta_porcent NUMBER :=0; -- contador de productos rebajados por porcentaje
	
	v_rebaja_porcent NUMBER;    -- rebaja aplicando el porcentaje
    v_rebaja NUMBER; -- rebaja a aplicar

							
BEGIN

	-- Se consulta si existe la gama
	SELECT gama INTO v_gama
	FROM gamasProductos
	WHERE gama = gama_prod;

	OPEN c_productos; -- se abre el cursor
	
	LOOP
	 		-- Se lee el siguiente producto del cursor
			FETCH c_productos INTO v_cod_prod, v_precio_venta;
	 
			EXIT WHEN c_productos%NOTFOUND; -- cuando no encuentre m�s productos
	
			-- Se calcula la diferencia por porcentaje
			v_rebaja_porcent := v_precio_venta * porcentaje /100;

			-- Se compara la rebaja por porcentaje con el importe
			IF (v_rebaja_porcent <= importe) THEN
					v_rebaja := v_rebaja_porcent;
					v_conta_porcent := v_conta_porcent +1;
			ELSE
				    v_rebaja := importe;
					v_conta_importe := v_conta_importe +1;
			END IF;
			
			-- Se modifica el precio de venta del producto
			UPDATE productos
			SET precioVenta = precioVenta - v_rebaja
			WHERE CURRENT OF c_productos;

	END LOOP;	
	
			-- Se muestra el resumen de contadores 
			DBMS_OUTPUT.PUT_LINE('TOTAL PEDIDOS:' || c_productos%ROWCOUNT);
			DBMS_OUTPUT.PUT_LINE('PEDIDOS REBAJADOS POR IMPORTE:' || v_conta_importe);
			DBMS_OUTPUT.PUT_LINE('PEDIDOS REBAJADOS POR PORCENTAJE:' || v_conta_porcent);
    
	CLOSE c_productos; -- se cierra el cursor
	
	EXCEPTION
		WHEN NO_DATA_FOUND THEN
				DBMS_OUTPUT.PUT_LINE('Error no existe la gama especificada');
		WHEN TOO_MANY_ROWS THEN
				DBMS_OUTPUT.PUT_LINE('Error existen varios gamas con el mismo c�digo');
		WHEN OTHERS THEN
				DBMS_OUTPUT.PUT_LINE('Error en la aplicaci�n');
END;
